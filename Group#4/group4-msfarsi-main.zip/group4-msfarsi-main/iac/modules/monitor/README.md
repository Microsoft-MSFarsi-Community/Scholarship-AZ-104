# Monioring

## Enabled diagnostic settings

### Categories

- allLogs

### Metrics

- AllMetrics

### Destination details

- Log Analytics Workspace

### Destination table

- Resource specific (`Dedicated`)

## Date retention

- Data retention in days. `30` is usually the minimum allowed for basic needs
