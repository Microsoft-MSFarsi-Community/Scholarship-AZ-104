# Infrastructure Implementation by Terraform (IaC)

We use _Terraform_ for provisiong infrastructures of our scenario in group #4. This process takes about _15 minutes_ to be completed.
